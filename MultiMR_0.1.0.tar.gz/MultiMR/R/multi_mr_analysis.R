#' Multi-Mendelian Randomization Analysis
#'
#' @param exposures A named list of exposure IDs and names.
#' @param outcomes A named list of outcome IDs and names.
#' @param significance_threshold The significance threshold for heterogeneity and pleiotropy tests.
#' @return A list with two data frames: MR_Results and Radial_Results.
#' @import dplyr
#' @import TwoSampleMR
#' @import RadialMR
#' @import writexl
#' @export
multi_mr_analysis <- function(exposures, outcomes, significance_threshold = 0.05) {
  
  # Create an empty list to store results
  results_list <- list()
  
  # Loop through each exposure-outcome combination
  for (exp_id in names(exposures)) {
    # Extract exposure SNPs
    exposure_data <- extract_instruments(exp_id)
    
    for (outcome_id in names(outcomes)) {
      # Extract outcome data for the current exposure SNPs
      outcome_data <- extract_outcome_data(snps = exposure_data$SNP, outcomes = outcome_id)
      
      # Harmonize data between exposure and outcome
      harmonized_data <- harmonise_data(exposure_data, outcome_data)
      harmonized_data <- subset(harmonized_data, mr_keep == "TRUE")
      
      # Perform MR analysis using inverse variance weighting (IVW)
      mr_result <- generate_odds_ratios(mr(harmonized_data, method_list = c('mr_ivw')))
      
      # Format MR results
      mr_result$`OR(95% CI)` <- paste(round(mr_result$or, 3), "(", round(mr_result$or_lci95, 3), ",", round(mr_result$or_uci95, 3), ")", sep = "")
      formatted_result <- mr_result[, c("nsnp", "exposure", "outcome", "OR(95% CI)", "se", "pval")]
      
      # Conduct heterogeneity and pleiotropy tests
      heterogeneity <- mr_heterogeneity(harmonized_data)
      heterogeneity_result <- data.frame(Q.Pval = heterogeneity$Q_pval[2])
      
      pleiotropy <- mr_pleiotropy_test(harmonized_data)
      pleiotropy_result <- data.frame(Int.Pval = pleiotropy$pval[1])
      
      # Combine MR results with heterogeneity and pleiotropy tests
      final_result <- cbind(formatted_result, heterogeneity_result, pleiotropy_result)
      
      # Store the results in the list with identifiers for exposure and outcome
      results_list[[paste(exposures[[exp_id]], outcomes[[outcome_id]], sep = " -> ")]] <- final_result
    }
  }
  
  # Combine all results into a single data frame for a comprehensive summary
  combined_results <- do.call(rbind, results_list)
  
  # Reorder columns to place exposure and outcome names at the front
  ma1 <- combined_results[, c("exposure", "outcome", "nsnp", "OR(95% CI)", "se", "pval", "Q.Pval", "Int.Pval")]
  
  ##### Radial Test #################################################
  # Create an empty list to store results
  results_list_radial <- list()
  
  # Loop through each exposure-outcome combination again for radial analysis
  for (exp_id in names(exposures)) {
    exposure_data <- extract_instruments(exp_id)
    
    for (outcome_id in names(outcomes)) {
      outcome_data <- extract_outcome_data(snps = exposure_data$SNP, outcomes = outcome_id)
      harmonized_data <- harmonise_data(exposure_data, outcome_data)
      harmonized_data <- subset(harmonized_data, mr_keep == "TRUE")
      
      # Run initial radial IVW and Egger tests
      ivw_res <- tryCatch({ ivw_radial(harmonized_data) }, error = function(e) { NULL })
      egger_res <- tryCatch({ egger_radial(harmonized_data) }, error = function(e) { NULL })
      
      # Identify influential SNPs for both tests
      influential_snp_ivw <- if (!is.null(ivw_res) && nrow(ivw_res[["outliers"]]) > 0) {
        ivw_res[["outliers"]][, 1]
      } else {
        NULL
      }
      
      influential_snp_egger <- if (!is.null(egger_res) && nrow(egger_res[["outliers"]]) > 0) {
        egger_res[["outliers"]][, 1]
      } else {
        NULL
      }
      
      # Remove influential SNPs from the harmonized data
      if (!is.null(influential_snp_ivw)) {
        harmonized_data <- dplyr::anti_join(harmonized_data, data.frame(SNP = influential_snp_ivw), by = "SNP")
      }
      
      if (!is.null(influential_snp_egger)) {
        harmonized_data <- dplyr::anti_join(harmonized_data, data.frame(SNP = influential_snp_egger), by = "SNP")
      }
      
      # Run MR analysis again without influential SNPs
      mr_result <- generate_odds_ratios(mr(harmonized_data, method_list = c('mr_ivw')))
      
      # Format MR results
      mr_result$`OR(95% CI)` <- paste(round(mr_result$or, 3), "(", round(mr_result$or_lci95, 3), ",", round(mr_result$or_uci95, 3), ")", sep = "")
      formatted_result <- mr_result[, c("nsnp", "exposure", "outcome", "OR(95% CI)", "se", "pval")]
      
      heterogeneity <- mr_heterogeneity(harmonized_data)
      heterogeneity_result <- data.frame(Q.Pval = heterogeneity$Q_pval[2])
      
      pleiotropy <- mr_pleiotropy_test(harmonized_data)
      pleiotropy_result <- data.frame(Int.Pval = pleiotropy$pval[1])
      
      final_result <- cbind(formatted_result, heterogeneity_result, pleiotropy_result)
      
      # Store the results in the list
      results_list_radial[[paste(exposures[[exp_id]], outcomes[[outcome_id]], sep = " -> ")]] <- final_result
    }
  }
  
  # Combine all results into a single data frame for a comprehensive summary
  combined_results_radial <- do.call(rbind, results_list_radial)
  ma2 <- combined_results_radial[, c("exposure", "outcome", "nsnp", "OR(95% CI)", "se", "pval", "Q.Pval", "Int.Pval")]
  
  ### Check the Radial test from ma1 and ma2 ######
  for (i in 1:nrow(ma1)) {
    if (is.na(ma1$Q.Pval[i]) | is.na(ma1$Int.Pval[i])) {
      ma2[i, ] <- ma1[i, ]  # If the tests are not valid, use the original results
    } else if (ma1$Q.Pval[i] > significance_threshold & ma1$Int.Pval[i] >= significance_threshold) {
      ma2[i, ] <- ma1[i, ]  # If neither test is significant, use the original results
    }
  }
  
  # Combine ma1 and ma2 for a final unified result
  final_combined_result <- cbind(ma1, ma2)
  # Write the final combined result to an Excel file
  write_xlsx(final_combined_result, "result.xlsx")
  return(list(final_combined_result))
}
